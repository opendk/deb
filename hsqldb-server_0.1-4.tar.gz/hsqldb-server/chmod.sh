chmod -R 644 debian/*
